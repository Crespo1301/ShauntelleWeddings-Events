const menuToggle = document.querySelector('.menu-toggle');
const siteNav = document.querySelector('.site-nav');

if (menuToggle && siteNav) {
  menuToggle.addEventListener('click', () => {
    const isOpen = siteNav.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded', String(isOpen));
  });
}

document.querySelectorAll('[data-carousel]').forEach((carousel) => {
  const track = carousel.querySelector('[data-carousel-track]');
  const slides = Array.from(carousel.querySelectorAll('[data-carousel-slide]'));
  const prev = carousel.querySelector('[data-carousel-prev]');
  const next = carousel.querySelector('[data-carousel-next]');
  const dotsWrap = carousel.parentElement.querySelector('[data-carousel-dots]');
  let index = 0;

  if (!track || !slides.length) return;

  slides.forEach((_, i) => {
    if (!dotsWrap) return;
    const dot = document.createElement('button');
    dot.type = 'button';
    dot.className = 'carousel-dot' + (i === 0 ? ' is-active' : '');
    dot.setAttribute('aria-label', `Go to slide ${i + 1}`);
    dot.addEventListener('click', () => goTo(i));
    dotsWrap.appendChild(dot);
  });

  const dots = dotsWrap ? Array.from(dotsWrap.querySelectorAll('.carousel-dot')) : [];

  function update() {
    track.style.transform = `translateX(-${index * 100}%)`;
    dots.forEach((dot, i) => dot.classList.toggle('is-active', i === index));
  }

  function goTo(nextIndex) {
    index = (nextIndex + slides.length) % slides.length;
    update();
  }

  prev?.addEventListener('click', () => goTo(index - 1));
  next?.addEventListener('click', () => goTo(index + 1));
  update();
});

const galleryRoot = document.querySelector('[data-gallery]');
if (galleryRoot) {
  const featuredImage = document.getElementById('gallery-featured-image');
  const thumbs = Array.from(document.querySelectorAll('[data-gallery-thumb]'));
  const prev = document.querySelector('[data-gallery-prev]');
  const next = document.querySelector('[data-gallery-next]');
  const openButton = document.querySelector('[data-gallery-open]');
  const lightbox = document.querySelector('[data-lightbox]');
  const lightboxImage = document.querySelector('[data-lightbox-image]');
  const lightboxPrev = document.querySelector('[data-lightbox-prev]');
  const lightboxNext = document.querySelector('[data-lightbox-next]');
  const lightboxClose = document.querySelector('[data-lightbox-close]');
  let currentIndex = 0;

  function setGalleryImage(index) {
    currentIndex = (index + thumbs.length) % thumbs.length;
    const currentThumb = thumbs[currentIndex];
    const imageSrc = currentThumb.dataset.full || currentThumb.querySelector('img')?.getAttribute('src');
    const imageAlt = currentThumb.querySelector('img')?.getAttribute('alt') || 'Gallery image';
    if (featuredImage) {
      featuredImage.src = imageSrc;
      featuredImage.alt = imageAlt;
    }
    if (lightboxImage) {
      lightboxImage.src = imageSrc;
      lightboxImage.alt = imageAlt;
    }
    thumbs.forEach((thumb, i) => thumb.classList.toggle('is-active', i === currentIndex));
  }

  thumbs.forEach((thumb, index) => {
    thumb.addEventListener('click', () => setGalleryImage(index));
  });

  prev?.addEventListener('click', () => setGalleryImage(currentIndex - 1));
  next?.addEventListener('click', () => setGalleryImage(currentIndex + 1));

  openButton?.addEventListener('click', () => {
    if (!lightbox) return;
    lightbox.hidden = false;
    document.body.classList.add('lightbox-open');
    setGalleryImage(currentIndex);
  });

  lightboxPrev?.addEventListener('click', () => setGalleryImage(currentIndex - 1));
  lightboxNext?.addEventListener('click', () => setGalleryImage(currentIndex + 1));
  lightboxClose?.addEventListener('click', () => {
    if (!lightbox) return;
    lightbox.hidden = true;
    document.body.classList.remove('lightbox-open');
  });

  lightbox?.addEventListener('click', (event) => {
    if (event.target === lightbox) {
      lightbox.hidden = true;
      document.body.classList.remove('lightbox-open');
    }
  });

  document.addEventListener('keydown', (event) => {
    if (lightbox?.hidden === false) {
      if (event.key === 'Escape') {
        lightbox.hidden = true;
        document.body.classList.remove('lightbox-open');
      }
      if (event.key === 'ArrowLeft') setGalleryImage(currentIndex - 1);
      if (event.key === 'ArrowRight') setGalleryImage(currentIndex + 1);
    }
  });

  setGalleryImage(0);
}
